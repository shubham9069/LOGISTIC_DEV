import React,{useContext} from 'react'
import './orderplace.css'
import {orderplace,sofa} from '../assest/Exportimage'
import {AuthContext} from '../../AuthProvider'
import { Fade } from 'react-reveal'
import { Link } from 'react-router-dom'


const OrderPlace = () => {

    const {userData,userToken} = useContext(AuthContext)
  return (
    <>
    <div className="order-top container center-div " >
    <Fade top>
        <div className='order-image'>
    <img  src={orderplace}/>
        </div>
        <div className='order-text text-center '>
        <h2>Thanku {userData.name} !</h2>
        <div style={{maxWidth:'700px'}}>
        <p className='lighptgrey-p'>The information you provided has been sent to our top secret wise quote calculating monks. We Will get you perfect tailor made quote in a day.</p>
        <p className='lighptgrey-p'><strong>Did you know</strong> you could reduce the price by choosing a weekday?<br/>
        You will be able lto see price trends near to the date of your move and choose accordingly.
        </p>
        <p className='lighptgrey-p' ><strong>Did you know</strong> you Can customise your package by telling what items you want packed?<br/>
Simply check the package option and let us know, or let us recommed the most popular option!</p>

        </div>

        </div>
        <div className='order-button'>
    <Link  to='/myorders' type="button" className="link-a myorder-btn" >My order</Link>
        </div>
        </Fade>
        <div className='bottom-box section-margin'>
           
            <div >
                <strong>#Order_id</strong>
                <p>order_id</p>
                <p>order_id</p>
            </div>
            <div>
            <strong>Move Type</strong>
                <p>order_id</p>
                <p>order_id</p>
            </div>
            <div>
            <strong>User Information</strong>
                <p>order_id</p>
                <p>order_id</p>
            </div>
            <div>
            <strong>From</strong>
                <p>order_id</p>
                <p>order_id</p>
            </div>
            <div>
            <strong>To</strong>
                <p>order_id</p>
                <p>order_id</p>
            </div>
            <div>
            <strong>Date & TimeSlot</strong>
                <p>order_id</p>
                <p>order_id</p>
            </div>
        </div>
        <div>
            <p style={{fontWeight:600,fontSize:'16px'}}>Your Selected Items</p>
        </div>
    <div className='itemlist-container'>

    <Fade bottom>
    <div className='item-list-box '>
       <div>
        <img src={sofa}></img>
       </div>
       <div>
        <p style={{margin:'3px'}}>Tv 1</p>
        <p style={{fontSize:'12px'}}>24 inch wall mounted</p>
        </div>
    </div>
    <div className='item-list-box '>
       <div>
        <img src={sofa}></img>
       </div>
       <div>
        <p style={{margin:'3px'}}>Tv 1</p>
        <p style={{fontSize:'12px'}}>24 inch wall mounted</p>
        </div>
    </div>
    <div className='item-list-box '>
       <div>
        <img src={sofa}></img>
       </div>
       <div>
        <p style={{margin:'3px'}}>Tv 1</p>
        <p style={{fontSize:'12px'}}>24 inch wall mounted</p>
        </div>
    </div>
    </Fade>
        </div>
    </div>


    </>
  )
}

export default OrderPlace